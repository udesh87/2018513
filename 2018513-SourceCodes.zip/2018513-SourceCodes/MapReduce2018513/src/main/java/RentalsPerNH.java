import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Counter;
import org.apache.hadoop.fs.FileSystem;



import java.io.IOException;

public class RentalsPerNH {

    public static class CountNumRentalsByNH extends
            Mapper<LongWritable, Text, NullWritable, NullWritable> {

        public static final String NH_COUNTER_GROUP = "NeighbourHood";


        public void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {

            String rowString = value.toString();
            String[] columnValues = rowString.split(",");
            String neighbourhood = String.valueOf(columnValues[4]).trim();
            if(key.get() != 0) {
                context.getCounter(NH_COUNTER_GROUP, neighbourhood).increment(1);
            }

        }

    }

        public static void main(String[] args) throws Exception {
            Configuration conf = new Configuration();
            String[] otherArgs = new GenericOptionsParser(conf, args)
                    .getRemainingArgs();

            if (otherArgs.length != 2) {
                System.err.println("Usage: CountNumUsersByState <users> <out>");
                System.exit(2);
            }

            Path input = new Path(otherArgs[0]);
            Path outputDir = new Path(otherArgs[1]);

            Job job = Job.getInstance(conf, "Count Num Rentals By Nieghbourhood");
            job.setJarByClass(RentalsPerNH.class);

            job.setMapperClass(CountNumRentalsByNH.class);
            job.setNumReduceTasks(0);

            job.setOutputKeyClass(NullWritable.class);
            job.setOutputValueClass(NullWritable.class);

            FileInputFormat.addInputPath(job, input);
            FileOutputFormat.setOutputPath(job, outputDir);

            int code = job.waitForCompletion(true) ? 0 : 1;
            System.out.println("==================================================");
            if (code == 0) {
                for (Counter counter : job.getCounters().getGroup(
                        CountNumRentalsByNH.NH_COUNTER_GROUP)) {
                    System.out.println(counter.getDisplayName() + "\t"
                            + counter.getValue());
                }
            }
            System.out.println("==================================================");
            // Clean up empty output directory


            FileSystem.get(conf).delete(outputDir, true);

            System.exit(code);
        }



}
